import os
import sys

from conan import ConanFile
from conan.tools.build import check_min_cppstd, check_max_cppstd
from conan.tools.cmake import CMakeToolchain, CMake, cmake_layout, CMakeDeps
from conan.tools.files import get

script_dir = os.path.dirname(__file__)
mymodule_dir = os.path.join(script_dir, '..', '..')
sys.path.append(mymodule_dir)

STELLAR_FORGE_VERSION = "rc-v0.1.0"


class StellarForgeCommon(ConanFile):
    name = "stellar-forge-common"
    version = STELLAR_FORGE_VERSION

    # Optional metadata
    url = "https://github.com/epitech-mirroring/Stellar-Forge"
    description = "Common library for Stellar-Forge"

    # Binary configuration
    settings = "os", "compiler", "build_type", "arch"
    options = {"shared": [False], "fPIC": [True]}
    default_options = {"shared": False, "fPIC": True}

    # Sources are located in the same place as this recipe, copy them to the recipe
    exports_sources = mymodule_dir + "/CMakeLists.txt", mymodule_dir + "/src/common/*"

    def config_options(self):
        if self.settings.os == "Windows":
            del self.options.fPIC

    def source(self):
        get(self,
            "https://github.com/epitech-mirroring/Stellar-Forge/archive/common-sources-" + STELLAR_FORGE_VERSION + ".tar.gz",
            strip_root=True)

    def layout(self):
        cmake_layout(self)

    def validate(self):
        check_min_cppstd(self, "17")
        check_max_cppstd(self, "20")

    def requirements(self):
        self.requires("glm/1.0.1")

    def generate(self):
        deps = CMakeDeps(self)
        deps.generate()
        tc = CMakeToolchain(self)
        tc.generate()

    def build(self):
        cmake = CMake(self)
        cmake.configure()
        cmake.build()

    def package(self):
        cmake = CMake(self)
        cmake.install()

    def package_info(self):
        self.cpp_info.libs = ["StellarForgeCommon"]
